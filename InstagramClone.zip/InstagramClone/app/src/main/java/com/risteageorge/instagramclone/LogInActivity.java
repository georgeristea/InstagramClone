package com.risteageorge.instagramclone;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class LogInActivity extends AppCompatActivity implements  View.OnClickListener {

    private EditText signUpName, logInName, signUpPass, logInPass;
    private Button signUpBtn, logInBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        signUpName = findViewById(R.id.SignUpName);
        signUpPass = findViewById(R.id.SignUpPass);

        signUpBtn = findViewById(R.id.SignUpBtn);
        logInBtn = findViewById(R.id.LogInBtn);



    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.SignUpBtn:


                break;

            case R.id.LogInBtn:


                break;
        }
    }
}
