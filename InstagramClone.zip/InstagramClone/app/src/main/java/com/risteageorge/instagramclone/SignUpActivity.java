package com.risteageorge.instagramclone;

import android.support.v7.app.;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.parse.ParseException;
import com.parse.ParseUser;
import com.parse.SignUpCallback;

public class SignUpActivity extends AppCompatActivity implements View.OnClickListener {

    EditText edtEmail, edtUsername, edtPass;
    Button signUpBtnMain, logInBtnMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        setTitle("SignUp");

        // EditText
        edtEmail = findViewById(R.id.edtEmail);
        edtUsername = findViewById(R.id.edtUsername);
        edtPass = findViewById(R.id.edtPass);

        // Butoane

        signUpBtnMain = findViewById(R.id.SignUpBtnMain);
        logInBtnMain = findViewById(R.id.LogInBtnMain);

    }

    @Override
    public void onClick(View v) {

        Toast.makeText(this, "ce are ba??", Toast.LENGTH_SHORT).show();
        switch (v.getId()) {

            case R.id.SignUpBtnMain:
                Log.i("LELELEL", " CE PLM ?");
                if (edtEmail.getText().toString().equals("") || edtUsername.getText().toString().equals("") ||
                        edtPass.getText().toString().equals("")) {

                    Toast.makeText(SignUpActivity.this, "Please complete all fields",
                            Toast.LENGTH_SHORT).show();
                }
                else {
                    ParseUser parseUser = new ParseUser();
                    parseUser.setEmail(edtEmail.getText().toString());
                    parseUser.setUsername(edtUsername.getText().toString());
                    parseUser.setPassword(edtPass.getText().toString());

                    parseUser.signUpInBackground(new SignUpCallback() {
                        @Override
                        public void done(ParseException e) {

                            if (e == null) {
                                Toast.makeText(SignUpActivity.this, "User " + edtUsername.getText().toString() + " sign up" +
                                        " successfully ", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }

                break;
            case R.id.LogInBtnMain:
                Toast.makeText(SignUpActivity.this, "Please complete all fields",
                        Toast.LENGTH_SHORT).show();
                break;
        }
    }
}
